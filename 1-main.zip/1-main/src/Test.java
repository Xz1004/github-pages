public class Test {
    public static void main(String[]args)throws Exception{
        SubwayNetwork subway =new SubwayNetwork();
        subway.loadData("1/src/subway.txt");
        //System.out.println(subway.getStations());
        //System.out.println(subway.getLines());
        //System.out.println(subway.getGraph());
        //System.out.println(subway.getTransferStations());
        //System.out.println(subway.findShortestPath("七里庙", "华中科技大学"));
        //System.out.println(subway.findNearbyStations("华中科技大学", 1.0));
        //System.out.println(subway.findAllPaths("华中科技大学", "红霞"));
        //subway.printJourneyGuide(subway.findShortestPath("华中科技大学", "红霞"));
        //subway.selectPathAndCalculateFare("华中科技大学", "红霞");
        }
    }